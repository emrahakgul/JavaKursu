package Day05;

public class Ornek4 {
    public static void main(String[] args) {

 // Double kilonuz int boy olacak şekilde tek satırda yazdır....
double kg =78.8;
int boy =175;

        System.out.println("Boyunuz: " + boy + "Kilonuz =" +kg);





    }
}
