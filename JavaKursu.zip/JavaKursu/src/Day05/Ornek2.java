package Day05;

public class Ornek2 {
    public static void main(String[] args) {

        // 2 tane

        /*double a=345.5;

        short b =545;

        short a1=(short) a;
        System.out.println(b);
        System.out.println(a);
        System.out.println(a1);
*/

        double sayi1= 45487878.4;
        short sayi2= 878;

        short sayi3=(short)sayi1;

        System.out.println("sayi3 = " + sayi3);






    }
}
