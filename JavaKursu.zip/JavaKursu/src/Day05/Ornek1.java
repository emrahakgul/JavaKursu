package Day05;

public class Ornek1 {

    public static void main(String[] args) {


        //3 farklı değişken tanımla ve değer ata

        int sayi = 5;

        char harf ='A';

        boolean cevap =true;


        System.out.println("sayi = " + sayi);
        System.out.println("harf = " + harf);
        System.out.println("cevap = " + cevap);




    }
}
