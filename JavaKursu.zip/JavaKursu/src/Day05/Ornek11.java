package Day05;

public class Ornek11 {


    public static void main(String[] args) {










    }

}
