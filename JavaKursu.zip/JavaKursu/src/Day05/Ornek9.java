package Day05;

public class Ornek9 {
    public static void main(String[] args) {

        String a ="5";


       int b =Integer.parseInt(a);
       int toplam= b*4;
        System.out.println("toplam = " + toplam);




    }
}
