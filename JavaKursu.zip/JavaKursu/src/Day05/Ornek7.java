package Day05;

public class Ornek7 {

    public static void main(String[] args) {

        // Short olarak atadığınız değeri stringe çevir...yazdır

        short a =129;

        String b =Short.toString(a);

        System.out.println("b = " + b);

        int a1 =65;

        String charli =Integer.toString(a1);
        System.out.println(charli);


        int sayi2 = 34; // matematiksel değer taşır işleme girer
        String kelimehali = "34"; // burda ise mat değeri yok işleme girmez ..sembol gibi









    }
}
