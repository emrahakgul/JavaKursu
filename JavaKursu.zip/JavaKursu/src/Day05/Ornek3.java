package Day05;

public class Ornek3 {

    public static void main(String[] args) {

        //short ve byte tanımla çevir

        short a= 455;
        byte b= 4;

        byte c=(byte)a;
        System.out.println(c);



    }
}
