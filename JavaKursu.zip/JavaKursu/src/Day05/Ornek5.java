package Day05;

public class Ornek5 {

    public static void main(String[] args) {

        //68 rakamınakarşılık gelen harfi önce 68 rakamını bir int değere atayarak bulunuz...


        int sayi1=68;

        char krk =(char)sayi1;

        System.out.println(krk);




    }

}


