package Day04;

public class WideningCasting {

    public static void main(String[] args) {

        int sayi = 9;
        double rakam =sayi;

        System.out.println("rakam = " + rakam);
    }
}
