package Day03;

public class CommentPrint {


    public static void main(String[] args) {


        System.out.println("Merhaba Dünya" );




    }

}
