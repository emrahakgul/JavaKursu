package Day03;

public class VariablesSoru {

    public static void main(String[] args) {
          // 2 kenarına değer verdiğiniz bir dikdörtgenin çeresini bulunuz..

        int a1=80;
        int b1=40;
        int çevre= a1*2 +b1*2;
        System.out.println("çevre = " + çevre);














    }
}
