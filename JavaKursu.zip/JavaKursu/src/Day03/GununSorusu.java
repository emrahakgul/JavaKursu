package Day03;

public class GununSorusu {

    public static void main(String[] args) {
   //Ekrana "Hello" , "World \ /" yazdır..

        System.out.println( "\"Hello\" , \"World\\ /\"");


    }
}
