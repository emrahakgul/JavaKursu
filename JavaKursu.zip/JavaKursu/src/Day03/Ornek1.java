package Day03;

public class Ornek1 {

    public static void main(String[] args) {
       /* System.out.println("P");
        System.out.println("a");
        System.out.println("z");
        System.out.println("a");
        System.out.println("r");
        System.out.println("t");
        System.out.println("e");
        System.out.println("s");
        System.out.println("i");

        System.out.println( "p\na\nz\na\nr\nt\n\ne\ns\ni"); */









    }
}
