package Day03;

public class EscapeCharacter {

    public static void main(String[] args) {
       //TODO KISAYOLLAR

        //yorum satırı oluşturma kısayolu
         // ctrl + / tuşlarına beraber basılınca seçilen satırlar yoruma geçer  ctrl  + shift +/ ta ise seçilen yerler yoruma girer

        /* System.out.println("Pazartesi");
        System.out.println("Salı");
        System.out.println("Çarşamba");

        //farklı biçimlerde yazma
        System.out.println("Pazartesi " + "Salı " + "Çarşamba");

        // System.out.print("Pazartesi \n Salı \n çarşamba");

        System.out.print("Pazartesi \t Salı \t çarşamba"); // \t ile araya tab kadar boşluk

        */
        //Çıft tırnak  koymak için
        System.out.println(" \"Java\" " );  //çift tırnak içinde  \" metin \" şeklinde

        // slaş koymak için
        System.out.println("\\Java"); // ikitane slaş ile konsola yazdırııken metnine slaş koyulabilir.











    }
}
