package Day03;

public class ScopeInceleme {

    public static void main(String[] args) {

       /* int a=5;
        { // değişkenin geçerlililk sınırı bu parantezlerin arasındadır...
            int b=7;
            a=8;
            System.out.println(a);
            // a ve b mevcut
        }
        // sadece a mevcut;

        //a=56;
        // b=6; bu şekide kullanamız çünkü değişken içerde

        System.out.println(a);


        byte a=4;
        System.out.println(a+ "kg"); */

        boolean a = true;

        System.out.println(a ? "evet" : "hayır");





    }
}
