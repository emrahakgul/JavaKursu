package Day03;

public class Print1 {
    public static void main(String[] args) {

        //TODO Haftanın 3 gününü yanyana ve altalta yazdır...

        System.out.println("Pazartesi");
        System.out.println("Salı");
        System.out.println("Çarşamba");

        System.out.print("Pazartesi ");
        System.out.print("Salı ");
        System.out.print("Çarşamba");



    }
}
