package Day02;

public class Merhaba {

    public static void main(String[] args) {

        //TODO Bu benim ilk programım

       // System.out.print("Javaya Hoş geldiniz! ");
        System.out.println("Merhaba Dünya!");













    }
}
